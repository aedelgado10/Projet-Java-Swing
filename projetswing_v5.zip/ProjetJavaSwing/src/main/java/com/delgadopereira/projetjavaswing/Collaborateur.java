/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.delgadopereira.projetjavaswing;
import java.util.ArrayList;
/**
 *
 * @author willem
 */
public class Collaborateur {

    private int id;
    private String nom;
    private String prenom;
    private String pseudo;
    private String mail;
    private String mdp;
    private ArrayList<Droit> d;
    public Etat etat; 
    private final ExecBD e;
    
    
    public Collaborateur(String pseudo,String mdp,ExecBD e){
        this.e = e;
        String query;
        query = "SELECT idCollab,nomCollab,prenomCollab,mailCollab FROM "
                + "Collaborateur WHERE pseudoColl"
                + "ab='" + pseudo + "' AND mdpCollab='" + mdp + "'";
    }
    
    public int getId() {
        return id;
    }

    private void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    private void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    private void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getPseudo() {
        return pseudo;
    }

    private void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }

    public String getMail() {
        return mail;
    }

    private void setMail(String mail) {
        this.mail = mail;
    }
    
    public String getMdp() {
        return mdp;
    }

    private void setMdp(String mdp) {
        this.mail = mdp;
    }

    public Etat getEtat() {
        return etat;
    }

    public void setEtat(Etat etat) {
        this.etat = etat;
    }
    
    public String getSallesDuCollab(){
        String query = "SELECT idsalle FROM AVOIR_DROITS_DANS_SALLE WHERE"
                + " idcollab =" + this.getId();
        return query;
    }
    
    
    public String getSallesDuCollabPublic(){
        String query = "SELECT S.idsalle,S.type FROM SALLE S, AVOIR_DROITS_DANS_SALLE A" 
                + "WHERE S.idsalle = A.idsalle AND A.idcollab = "+ this.getId() 
                + " AND type = 'Public'";
        return query;
    } 
    
    public String getSallesDuCollabPrivate(){
        String query = "SELECT S.idsalle,S.type FROM SALLE S, AVOIR_DROITS_DANS_SALLE A" 
                + "WHERE S.idsalle = A.idsalle AND A.idcollab = "+ this.getId() 
                + " AND type = 'Private'";
        return query;
    } 
    
    /**
     * Récupère la liste des salles d'un utilisateur pour une table
     * @param query
     * @return 
     */
    public ArrayList<Integer> fetch_salle(String query){
        
        ArrayList<Integer> a = new ArrayList<>();
        
        while (e.hasNext()){
            e.query(query);
            Integer ids = e.ifetch("idsalle");
            a.add(ids); 
        }
        
        return a;
    }
    
    /**
     * se connecter à une salle
     * @param idsalle 
     */
    public void se_connecter(int idsalle){
        etat = new Enligne(true);
        this.etat.update(this.id, idsalle, e);
    }
    
    /**
     * quitter une salle
     * @param idsalle 
     */
    public void se_deconnecter(int idsalle){
        this.etat.disconnect(this.id, idsalle, e);
    }
      
}
