/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.delgadopereira.projetjavaswing;

/**
 *
 * @author Delgado Pereira
 */
public class Utilisateur {
    
    public static Integer verifier(String user, String mdp,ExecBD e){
        
        e.query("SELECT idCollab "
                + "FROM Collaborateur"
                + " WHERE pseudocollab = '" + user + "' AND mdpCollab = '"+ mdp +"'");
        
        if (e.hasNext()){
            int idCollab = e.ifetch("idCollab");
            return idCollab;
        }
        else{
            return null;
        }
    }
    
}
