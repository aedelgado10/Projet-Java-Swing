/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.delgadopereira.projetjavaswing;

import java.util.ArrayList;

/**
 *
 * @author willem
 */
public class Salle {

    private int id;
    private String type;
    private String description;
    private String titre;
    private String dateCreation;
    private ArrayList<Message> m;
    private ExecBD e;
    
    public Salle(int idCollab,int idSalle,ExecBD e){
        this.e = e;
        this.id = idSalle;
        String query;
        query = "SELECT S.* FROM Collaborateur C, Salle S, "
                + "Administrateur A, Affecter Af WHERE S.idSalle = Af.idSalle "
                + "AND Af.idCollab = C.idCollab AND A.idAdmin = Af.idAdmin AND "
                + "C.idCollab ='"+ idCollab +"' AND S.idsalle='" + this.id + "'";
        
        e.query(query);
        
        while (e.hasNext()){
            
        }
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(String dateCreation) {
        this.dateCreation = dateCreation;
    }
    
    public int getNbrCollab(){
        int nbcollab;
        String query = "SELECT COUNT(idcollab) AS nbcollab FROM COLLABORATEUR";
        e.query(query);
        
        if (e.hasNext()){
            nbcollab= e.ifetch("nbcollab");
        }else{
            return -1;
        }
        return nbcollab;
    }
    
    /**
     * Après ajout du Message à la base de données (dans la classe message), 
     * incrémentation de cette Arraylist
     * @param m 
     */
    public void addMessageToHistorique(Message m){
        this.m.add(m);
    }
    
    /**
     * récuperation des collaborateurs dans la salle
     * @return 
     */
    public ArrayList<Integer> collaborateursDansSalle(){
        String query = "SELECT idCollab FROM affecter WHERE idSalle =" + this.id ;
        ArrayList<Integer> a = new ArrayList<>();
        e.query(query);
        
        while (e.hasNext()){
            e.query(query);
            Integer idc = e.ifetch("idCollab");
            a.add(idc); 
        }
        return a;
    }
    
}
