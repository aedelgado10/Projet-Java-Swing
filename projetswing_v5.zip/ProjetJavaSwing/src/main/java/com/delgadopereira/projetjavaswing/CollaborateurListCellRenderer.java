/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.delgadopereira.projetjavaswing;

import java.awt.Component;
import javax.swing.Icon;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;

/**
 *
 * @author willem
 */
public class CollaborateurListCellRenderer extends DefaultTreeCellRenderer{
    private final Icon online;
    private final Icon offline;
    private final Icon away;
    
    public CollaborateurListCellRenderer(Icon on, Icon off, Icon away){
        this.online = on;
        this.offline = off;
        this.away = away;
    }
    
    @Override
    public Component getTreeCellRendererComponent( JTree tree,Object value,boolean sel,boolean expanded,boolean leaf,int row,boolean hasFocus){
       if (value instanceof Collaborateur){
           Collaborateur c = (Collaborateur)value; 
           if( c.etat instanceof Enligne ){
               setLeafIcon(online);
               setText("Connectés");
           }
           else if (c.etat instanceof Absent){
               setLeafIcon(away);
               setText("Absents");
           }
           else{
               setLeafIcon(offline);
               setText("Deconnectés");
           }
       }
       return this;
    }

    
    
    
    
}
