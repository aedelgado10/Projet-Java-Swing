/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.delgadopereira.projetjavaswing;

/**
 *
 * @author willem
 */
public class Administrateur extends Collaborateur {
    
    private int idAdmin;
    
    public Administrateur(String pseudo, String mdp,ExecBD e){
        super(pseudo,mdp,e);
        String query;
        query = "SELECT Administrateur.idAdmin FROM Administrateur ,"
                + "Collaborateur, ETRE WHERE ETRE.idCollab = Collaborateur.idCollab"
                + " AND ETRE.idAdmin = Administrateur.idAdmin AND"
                + " Collaborateur.pseudoCollab='"+ pseudo +"'";
        
    } 
    
    public int getIdAdmin() {
        return idAdmin;
    }

    private void setIdAdmin(int idAdmin) {
        this.idAdmin = idAdmin;
    }
    
    public int getNbrSallesCrees(ExecBD e){
        int nbsalles;
        String query = "SELECT COUNT(idsalle) as sallesCrees FROM CREER" 
        + "WHERE idadmin=" + this.idAdmin;
        e.query(query);
        
        if (e.hasNext()){
            nbsalles= e.ifetch("nbcollab");
        }else{
            return -1;
        }
        return nbsalles;
    }
    
    // cette fonction s'utilise avec fetch_salles du Super : Collaborateur
    public String getSallesCrees(){
        String query = "SELECT idsalle FROM CREER WHERE idadmin=" + this.idAdmin;
        return query;
    }
    
    public void creerSalle(Salle s, ExecBD e){
        String query = "INSERT INTO Salle VALUES("+ s.getId() +",'" + s.getType() 
                + "','" + s.getDescription() + "','"
                + s.getTitre() + "','" + s.getDateCreation() + "')"; 
        
        e.query(query);
    }
}
