/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.delgadopereira.projetjavaswing;

import java.util.ArrayList;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

/**
 *
 * @author willem
 */
public class ModeleCollaborateurClient implements TreeModel{
    
    ArrayList<Collaborateur> listeCollab;
    
    public ModeleCollaborateurClient(ArrayList<Collaborateur> l){
        this.listeCollab = l ;
    }
    
    @Override
    public Object getRoot() {
        return "Collaborateurs";
    }

    @Override
    public Object getChild(Object parent, int index) {
        return listeCollab.get(index);
    }

    @Override
    public int getChildCount(Object parent) {
        return listeCollab.size();
    }

    @Override
    public boolean isLeaf(Object node) {
        return true;
    }

    @Override
    public void valueForPathChanged(TreePath path, Object newValue) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getIndexOfChild(Object parent, Object child) {
        Collaborateur c = (Collaborateur) child;
        return c.getId();
    }

    @Override
    public void addTreeModelListener(TreeModelListener l) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void removeTreeModelListener(TreeModelListener l) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
