/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.delgadopereira.projetjavaswing;

import java.util.ArrayList;

/**
 *
 * @author Delgado Pereira
 */
public class IHM {
    
    
    public static void charger(Integer userType,
            String pseudo,String mdp,ExecBD e){
        
        switch(userType){
            case 1:
                //Andrés: preparer la mierda
                IHM_Admin iAdmin = new IHM_Admin();
                iAdmin.setVisible(true);
                break;
            default:
                //will : client
                Collaborateur c = new Collaborateur(pseudo,mdp,e);
                //Salle sallesC = new Salle(userType,e);
                
                ArrayList<Integer> listesalles = c.fetch_salle(c.getSallesDuCollab());
                int nbr_membre_salles = listesalles.size();
                
                ArrayList<Integer> listeSallesPrive = c.fetch_salle(c.getSallesDuCollabPrivate());
                int nbr_discussions_prives = listeSallesPrive.size();
                
                IHM_Client iClient = new IHM_Client();
                iClient.setVisible(true);
                break;
       }
        
    }
    
}
